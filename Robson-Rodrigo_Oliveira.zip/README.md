# Trabalho de Ciências de Dados
Repositório destinado a trabalhar em equipe e descobrir o que fazer e apresentar na matéria de Ciências de Dados, idealizado por quatro pessoas a pesar de serem divididos em duplas.
